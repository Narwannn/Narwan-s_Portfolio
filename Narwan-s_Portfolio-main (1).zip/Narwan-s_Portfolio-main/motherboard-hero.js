(() => {
'use strict';
const hero=document.querySelector('#home');if(!hero)return;
let active=false,startX=0,startY=0,x=0,y=0,originX=0,originY=0;
function paint(){hero.style.setProperty('--pan-x',x+'px');hero.style.setProperty('--pan-y',y+'px')}
hero.addEventListener('pointerdown',e=>{if(e.target.closest('a,button')||e.pointerType==='touch')return;active=true;startX=e.clientX;startY=e.clientY;originX=x;originY=y;hero.setPointerCapture(e.pointerId);hero.classList.add('nj-dragging')});
hero.addEventListener('pointermove',e=>{if(!active)return;x=Math.max(-22,Math.min(22,originX+(e.clientX-startX)*.22));y=Math.max(-16,Math.min(16,originY+(e.clientY-startY)*.18));paint()});
function stop(){active=false;hero.classList.remove('nj-dragging')}
hero.addEventListener('pointerup',stop);hero.addEventListener('pointercancel',stop);hero.addEventListener('lostpointercapture',stop);
hero.querySelector('.nj-reset').addEventListener('click',()=>{x=0;y=0;paint()});
})();
